<?php

// _list_item.php
use yii\helpers\Html;
use yii\helpers\Url;
?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12" >
        <h3>Hai</h3>
    </div>
</div>